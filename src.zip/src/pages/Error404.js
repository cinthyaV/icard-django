import React from "react";

export function Error404() {
    return ( 
        <div>
        <h2> Error 404 </h2> </div>
    );
}