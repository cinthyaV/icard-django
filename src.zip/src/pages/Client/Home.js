import React from 'react'

export function Home() {
    return ( <
        div >
        <
        p > Estamos en la Home < /p> <
        /div>
    )
}