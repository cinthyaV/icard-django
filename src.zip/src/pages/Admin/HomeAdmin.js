import React from "react";

export function HomeAdmin() {
      return ( 
        <div>
        <h1> Home Admin </h1>     
   </div>
    );
}
